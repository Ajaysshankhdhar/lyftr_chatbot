import uuid

from app import llm


def sid():
    return "s-" + uuid.uuid4().hex[:10]


def uniq(text="hello"):
    return f"{text} {uuid.uuid4().hex}"


def chat(client, session, message, headers=None, **extra):
    return client.post(
        "/chat", json={"session_id": session, "message": message, **extra}, headers=headers or {}
    )


def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok", "keys_configured": 2, "cache_enabled": True}


def test_chat_live_then_cache_in_new_session(client):
    msg = uniq("capital of France?")
    a = chat(client, sid(), msg).json()
    b = chat(client, sid(), msg).json()
    assert a["metadata"]["resolution_source"] == "LIVE_INFERENCE"
    assert a["metadata"]["key_id"] == "key_1"
    assert b["metadata"]["resolution_source"] == "LLM_CACHE"
    assert b["metadata"]["key_id"] is None
    assert b["metadata"]["fallback_attempts"] == 0
    assert a["reply"] == b["reply"]
    assert b["metadata"]["input_tokens"] == a["metadata"]["input_tokens"]
    assert isinstance(b["metadata"]["latency_ms"], int)


def test_different_message_not_cached(client):
    first = chat(client, sid(), uniq("one")).json()
    second = chat(client, sid(), uniq("two")).json()
    assert first["metadata"]["resolution_source"] == "LIVE_INFERENCE"
    assert second["metadata"]["resolution_source"] == "LIVE_INFERENCE"


def test_multi_turn_history_and_isolation(client):
    s1, s2 = sid(), sid()
    chat(client, s1, uniq("first"))
    chat(client, s1, uniq("second"))
    chat(client, s2, uniq("other"))
    h1 = client.get(f"/sessions/{s1}/messages").json()
    assert [m["role"] for m in h1["messages"]] == ["user", "assistant", "user", "assistant"]
    assert "metadata" in h1["messages"][1] and "metadata" not in h1["messages"][0]
    assert len(client.get(f"/sessions/{s2}/messages").json()["messages"]) == 2


def test_tokens_are_per_request(client):
    a = chat(client, sid(), "same length one").json()["metadata"]["input_tokens"]
    b = chat(client, sid(), "same length two").json()["metadata"]["input_tokens"]
    assert abs(a - b) <= 2


def test_failover_single_key(client):
    for header in ("key_1=429", "key_1=500"):
        r = chat(client, sid(), uniq("failover"), {"X-Simulate-Failure": header})
        assert r.status_code == 200
        meta = r.json()["metadata"]
        assert meta["key_id"] == "key_2" and meta["fallback_attempts"] == 1
        assert meta["resolution_source"] == "LIVE_INFERENCE"


def test_failover_works_even_if_message_is_cached(client):
    msg = uniq("cached first")
    chat(client, sid(), msg)
    r = chat(client, sid(), msg, {"X-Simulate-Failure": "key_1=429"})
    assert r.json()["metadata"]["key_id"] == "key_2"


def test_all_keys_fail_503_not_stored(client):
    s = sid()
    r = chat(client, s, uniq("doomed"), {"X-Simulate-Failure": "*=429"})
    assert r.status_code == 503
    assert r.json() == {"detail": "all providers unavailable"}
    assert client.get(f"/sessions/{s}/messages").status_code == 404
    r = chat(client, s, uniq("doomed"), {"X-Simulate-Failure": "key_1=429,key_2=500"})
    assert r.status_code == 503


def test_validation_errors(client):
    assert client.post("/chat", json={"session_id": "x", "message": "   "}).status_code == 422
    assert client.post("/chat", json={"session_id": "", "message": "hi"}).status_code == 422
    assert client.post("/chat", json={"message": "hi"}).status_code == 422
    assert client.post("/chat", json={"session_id": "x", "message": "a" * 4001}).status_code == 422
    r = client.post("/chat", content="{bad json", headers={"Content-Type": "application/json"})
    assert r.status_code == 422 and "detail" in r.json()


def test_unknown_session_404(client):
    r = client.get("/sessions/nope-" + uuid.uuid4().hex + "/messages")
    assert r.status_code == 404 and r.json() == {"detail": "session not found"}


def test_simulation_disabled_flag(client, monkeypatch):
    monkeypatch.setattr(llm.settings, "simulation_enabled", False)
    r = chat(client, sid(), uniq("no sim"), {"X-Simulate-Failure": "*=429"})
    assert r.status_code == 200 and r.json()["metadata"]["key_id"] == "key_1"
