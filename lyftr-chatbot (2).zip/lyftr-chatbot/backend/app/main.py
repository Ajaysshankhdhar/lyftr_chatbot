import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from . import db, llm
from .config import settings

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("app")


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="LLM Chatbot", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=128)
    message: str
    system_prompt: str | None = Field(default=None, max_length=8000)

    @field_validator("message")
    @classmethod
    def _message(cls, v: str) -> str:
        v = v.strip()
        if not 1 <= len(v) <= 4000:
            raise ValueError("message must be 1-4000 characters after trimming")
        return v


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    log.exception("unhandled error")
    return JSONResponse(status_code=500, content={"detail": "internal server error"})


@app.get("/health")
def health():
    if not db.ping():
        return JSONResponse(status_code=503, content={"detail": "database unavailable"})
    if not settings.keys:
        return JSONResponse(status_code=503, content={"detail": "no API keys configured"})
    return {
        "status": "ok",
        "keys_configured": len(settings.keys),
        "cache_enabled": llm.litellm.cache is not None,
    }


@app.post("/chat")
def chat(body: ChatRequest, x_simulate_failure: str | None = Header(default=None)):
    start = time.perf_counter()
    system_prompt = (body.system_prompt or "").strip() or None
    effective_prompt = (
        system_prompt or db.get_system_prompt(body.session_id) or settings.default_system_prompt
    )

    messages = (
        [{"role": "system", "content": effective_prompt}]
        + db.get_history(body.session_id, settings.max_history)
        + [{"role": "user", "content": body.message}]
    )

    try:
        result = llm.complete(messages, llm.parse_simulation(x_simulate_failure))
    except llm.AllProvidersUnavailable:
        return JSONResponse(status_code=503, content={"detail": "all providers unavailable"})

    metadata = {
        "resolution_source": "LLM_CACHE" if result.cached else "LIVE_INFERENCE",
        "model": settings.model,
        "latency_ms": max(1, int((time.perf_counter() - start) * 1000)),
        "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
        "key_id": result.key_id,
        "fallback_attempts": result.fallback_attempts,
    }
    db.save_exchange(body.session_id, system_prompt, body.message, result.reply, metadata)
    return {"session_id": body.session_id, "reply": result.reply, "metadata": metadata}


@app.get("/sessions/{session_id}/messages")
def session_messages(session_id: str):
    messages = db.get_messages(session_id)
    if messages is None:
        return JSONResponse(status_code=404, content={"detail": "session not found"})
    return {"session_id": session_id, "messages": messages}
