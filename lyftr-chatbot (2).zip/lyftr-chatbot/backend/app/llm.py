"""LiteLLM gateway: key pool, ordered failover, built-in response cache."""
import logging
import threading
import time
from dataclasses import dataclass

import litellm

from .config import settings

log = logging.getLogger("llm")

litellm.drop_params = True
litellm.cache = litellm.Cache(type="local")  # LiteLLM's in-memory cache

SIM_STATUSES = {429, 500, 502, 503}


class AllProvidersUnavailable(Exception):
    pass


class SimulatedFailure(Exception):
    def __init__(self, status: int):
        super().__init__(f"simulated provider status {status}")
        self.status = status


@dataclass
class LLMResult:
    reply: str
    cached: bool
    key_id: str | None
    fallback_attempts: int
    input_tokens: int
    output_tokens: int


_cooldowns: dict[str, float] = {}
_lock = threading.Lock()


def key_pool() -> list[tuple[str, str]]:
    return [(f"key_{i}", k) for i, k in enumerate(settings.keys, start=1)]


def parse_simulation(header: str | None) -> dict[str, int]:
    """'key_1=429,key_2=500' or '*=429' -> {key_id: status}. Ignores malformed pairs."""
    if not header or not settings.simulation_enabled:
        return {}
    result: dict[str, int] = {}
    for pair in header.split(","):
        if "=" not in pair:
            continue
        name, _, status = pair.partition("=")
        name, status = name.strip(), status.strip()
        if not status.isdigit() or int(status) not in SIM_STATUSES:
            continue
        if name == "*":
            for key_id, _ in key_pool():
                result[key_id] = int(status)
        elif name:
            result[name] = int(status)
    return result


def _ordered_pool() -> list[tuple[str, str]]:
    now = time.time()
    with _lock:
        ready = [p for p in key_pool() if _cooldowns.get(p[0], 0) <= now]
        cooling = [p for p in key_pool() if _cooldowns.get(p[0], 0) > now]
    return ready + cooling  # never skip a key entirely: cooling keys are the last resort


def complete(messages: list[dict], simulate: dict[str, int]) -> LLMResult:
    failures = 0
    for key_id, api_key in _ordered_pool():
        try:
            if key_id in simulate:
                raise SimulatedFailure(simulate[key_id])
            kwargs = dict(
                model=settings.model,
                messages=messages,
                api_key=api_key,
                timeout=settings.request_timeout,
                num_retries=0,  # failover is handled here, not by retrying the same key
            )
            if settings.mock:
                kwargs["mock_response"] = "Mock reply to: " + messages[-1]["content"][:120]
            if simulate:
                # failover demos must return a real, live answer, so skip the cache read
                kwargs["cache"] = {"no-cache": True}
            resp = litellm.completion(**kwargs)
            text = (resp.choices[0].message.content or "").strip()
            if not text:
                raise ValueError("empty completion")
            cached = bool((getattr(resp, "_hidden_params", None) or {}).get("cache_hit"))
            usage = getattr(resp, "usage", None)
            return LLMResult(
                reply=text,
                cached=cached,
                key_id=None if cached else key_id,
                fallback_attempts=0 if cached else failures,
                input_tokens=int(getattr(usage, "prompt_tokens", 0) or 0),
                output_tokens=int(getattr(usage, "completion_tokens", 0) or 0),
            )
        except Exception as exc:  # 429, quota, 5xx, auth, timeout... -> next key
            failures += 1
            if not isinstance(exc, SimulatedFailure):
                with _lock:
                    _cooldowns[key_id] = time.time() + settings.cooldown_seconds
            log.warning("%s failed (%s: %s)", key_id, type(exc).__name__, str(exc)[:200])
    raise AllProvidersUnavailable()
