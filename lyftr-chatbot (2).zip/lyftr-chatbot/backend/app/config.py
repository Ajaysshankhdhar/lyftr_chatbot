import os
from dataclasses import dataclass, field


def _split(value: str) -> list[str]:
    return [v.strip() for v in value.split(",") if v.strip()]


@dataclass
class Settings:
    keys: list[str] = field(default_factory=list)
    database_url: str = "sqlite:////data/app.db"
    allowed_origins: list[str] = field(default_factory=list)
    simulation_enabled: bool = False
    model: str = "gemini/gemini-2.0-flash"
    mock: bool = False
    default_system_prompt: str = "You are a helpful assistant. Keep answers clear and concise."
    cooldown_seconds: int = 30
    request_timeout: int = 30
    max_history: int = 50

    @property
    def db_path(self) -> str:
        url = self.database_url
        if url.startswith("sqlite:///"):
            return url[len("sqlite:///"):]
        return url


def load_settings() -> Settings:
    return Settings(
        keys=_split(os.getenv("LLM_API_KEYS", "")),
        database_url=os.getenv("DATABASE_URL", "sqlite:////data/app.db"),
        allowed_origins=_split(os.getenv("ALLOWED_ORIGINS", "http://localhost:3000")),
        simulation_enabled=os.getenv("ENABLE_FAILURE_SIMULATION", "false").lower() == "true",
        model=os.getenv("LLM_MODEL", "gemini/gemini-2.0-flash"),
        mock=os.getenv("LLM_MOCK", "false").lower() == "true",
        default_system_prompt=os.getenv(
            "DEFAULT_SYSTEM_PROMPT",
            "You are a helpful assistant. Keep answers clear and concise.",
        ),
        cooldown_seconds=int(os.getenv("KEY_COOLDOWN_SECONDS", "30")),
        request_timeout=int(os.getenv("LLM_TIMEOUT_SECONDS", "30")),
        max_history=int(os.getenv("MAX_HISTORY_MESSAGES", "50")),
    )


settings = load_settings()
