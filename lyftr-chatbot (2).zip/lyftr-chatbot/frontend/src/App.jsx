import { useEffect, useRef, useState } from "react";

const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:8000").replace(/\/$/, "");

const FAILURE_PRESETS = [
  { label: "Off", value: "" },
  { label: "Key 1 rate-limited (429)", value: "key_1=429" },
  { label: "Key 1 server error (500)", value: "key_1=500" },
  { label: "Both keys down (429 + 500)", value: "key_1=429,key_2=500" },
  { label: "Every key rate-limited", value: "*=429" },
];

const newSessionId = () =>
  "s-" + (crypto.randomUUID ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10));

function errorText(status, data) {
  if (status === 503) return "All AI providers are unavailable right now. Wait a moment, then send again.";
  if (status === 422) return "Messages must be between 1 and 4000 characters. Edit yours and send again.";
  if (typeof data?.detail === "string") return data.detail;
  return "Something went wrong. Send your message again.";
}

function Meta({ m }) {
  return (
    <dl className="meta">
      <div>
        <dt>Source</dt>
        <dd data-testid="meta-source" className={m.resolution_source === "LLM_CACHE" ? "cache" : "live"}>
          {m.resolution_source}
        </dd>
      </div>
      <div>
        <dt>Model</dt>
        <dd data-testid="meta-model">{m.model}</dd>
      </div>
      <div>
        <dt>Latency</dt>
        <dd data-testid="meta-latency">{m.latency_ms} ms</dd>
      </div>
      <div>
        <dt>Input tokens</dt>
        <dd data-testid="meta-input-tokens">{m.input_tokens}</dd>
      </div>
      <div>
        <dt>Output tokens</dt>
        <dd data-testid="meta-output-tokens">{m.output_tokens}</dd>
      </div>
      <div>
        <dt>Key</dt>
        <dd>{m.key_id ?? "none (cached)"}</dd>
      </div>
      <div>
        <dt>Failed keys</dt>
        <dd>{m.fallback_attempts}</dd>
      </div>
    </dl>
  );
}

export default function App() {
  const [sessionId] = useState(newSessionId); // new session on every page load
  const [items, setItems] = useState([]);
  const [input, setInput] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [failure, setFailure] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [items, loading]);

  async function send() {
    const message = input.trim();
    if (!message || loading) return;
    setInput("");
    setItems((prev) => [...prev, { kind: "user", text: message }]);
    setLoading(true);
    try {
      const headers = { "Content-Type": "application/json" };
      if (failure) headers["X-Simulate-Failure"] = failure;
      const body = { session_id: sessionId, message };
      if (systemPrompt.trim()) body.system_prompt = systemPrompt.trim();
      const res = await fetch(`${API_URL}/chat`, { method: "POST", headers, body: JSON.stringify(body) });
      let data = null;
      try {
        data = await res.json();
      } catch {
        /* non-JSON body */
      }
      if (res.ok && data?.reply) {
        setItems((prev) => [...prev, { kind: "assistant", text: data.reply, meta: data.metadata }]);
      } else {
        setItems((prev) => [...prev, { kind: "error", text: errorText(res.status, data) }]);
      }
    } catch {
      setItems((prev) => [
        ...prev,
        { kind: "error", text: "Can't reach the server. Check your connection and send again." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function onKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <div className="app">
      <header className="top">
        <h1>Failover Chat</h1>
        <span className="sid">Session {sessionId}</span>
      </header>

      <details className="settings">
        <summary>Session settings</summary>
        <label>
          System prompt
          <textarea
            data-testid="system-prompt-input"
            rows={2}
            value={systemPrompt}
            placeholder="Optional. Overrides the default instructions for this session."
            onChange={(e) => setSystemPrompt(e.target.value)}
          />
        </label>
        <label>
          Simulate failure on next messages
          <select value={failure} onChange={(e) => setFailure(e.target.value)}>
            {FAILURE_PRESETS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </label>
      </details>

      <main className="thread" aria-live="polite">
        {items.length === 0 && (
          <p className="empty">Ask anything. Each reply shows where it came from, how long it took, and its token use.</p>
        )}
        {items.map((it, i) =>
          it.kind === "user" ? (
            <div key={i} className="msg user" data-testid="user-message">
              {it.text}
            </div>
          ) : it.kind === "assistant" ? (
            <div key={i} className="msg assistant" data-testid="assistant-message">
              <div className="reply">{it.text}</div>
              <Meta m={it.meta} />
            </div>
          ) : (
            <div key={i} className="msg error" role="alert">
              {it.text}
            </div>
          )
        )}
        {loading && <div className="msg pending">Thinking…</div>}
        <div ref={endRef} />
      </main>

      <footer className="composer">
        <textarea
          data-testid="chat-input"
          rows={1}
          value={input}
          placeholder="Type a message"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
        />
        <button data-testid="send-button" onClick={send} disabled={loading}>
          Send
        </button>
      </footer>
    </div>
  );
}
