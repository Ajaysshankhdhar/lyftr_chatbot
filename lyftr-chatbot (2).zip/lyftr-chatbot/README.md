# Failover Chat: LLM chatbot with key failover and response caching

React + FastAPI + SQLite, with LiteLLM handling the key pool and the response cache.

## 1. Live URLs

- Frontend: `<add your Vercel/Netlify URL>`
- Backend: `<add your Render/Railway URL>` (try `/health`)
- Demo video: `<add link>`

## 2. Run locally: with Docker and without

**Docker**

```bash
cp .env.example .env      # put 2+ real keys in LLM_API_KEYS
make up                   # frontend :3000, backend :8000
make down
```

**Without Docker**

```bash
# backend
cd backend && pip install -r requirements-dev.txt
export LLM_API_KEYS=key1,key2 DATABASE_URL=sqlite:///./app.db ENABLE_FAILURE_SIMULATION=true
uvicorn app.main:app --port 8000
# tests (no real keys needed, uses LiteLLM mock responses)
python -m pytest -q

# frontend
cd frontend && npm install && VITE_API_URL=http://localhost:8000 npm run dev
```

**Deploying**: backend as a Docker web service from `/backend` (set `LLM_API_KEYS`, `ALLOWED_ORIGINS=<frontend URL>`, `ENABLE_FAILURE_SIMULATION=true`, `DATABASE_URL=sqlite:////data/app.db`, and mount a disk at `/data` if the host offers one). Frontend as a static site from `/frontend` (build `npm run build`, output `dist`, env `VITE_API_URL=<backend URL>`).

## 3. Design decisions: key fallback, caching, SQLite session storage

- **Key fallback.** `LLM_API_KEYS` becomes `key_1, key_2, ...`. For each request the gateway tries keys in order via `litellm.completion(api_key=...)`. Any failure (429, quota, 5xx, auth, timeout, empty reply) moves to the next key. A key that really failed sits in a 30s cooldown and is tried last. If every key fails, the API returns `503 {"detail":"all providers unavailable"}` and nothing is written to history. Keys are never returned or logged; only `key_id` is.
- **Caching.** LiteLLM's built-in in-memory cache. Its key is the model plus the full message list (system prompt + history + new message), so the same first message in a new session hits the cache and a different message never does. A hit is detected from LiteLLM's `cache_hit` flag and reported as `LLM_CACHE` with `key_id: null`, the stored token usage and the identical reply.
- **Failure simulation.** `X-Simulate-Failure` is parsed only when `ENABLE_FAILURE_SIMULATION=true`. Simulated keys fail before any provider call, for that request only. Simulated requests skip the cache read so failover always returns a live answer from the next key.
- **SQLite.** `messages` table as specified, plus a small `sessions` table for the per-session system prompt. The schema is created on startup; the file lives at `DATABASE_URL` (a Docker volume at `/data`). A turn (user + assistant rows) is written in one transaction only after success, so 422/503 requests never appear in history. The client sends only the new message; the server rebuilds context from SQLite (last 50 messages).
- **Tokens and latency.** Tokens come from the provider's usage for this request only. Latency is server-measured and includes the DB reads, so cache hits are far faster than live calls.

## 4. Verification: how to see failover, cache hits and per-message token usage

```bash
B=http://localhost:8000
curl $B/health
# live, then cache hit (new session, same message)
curl -s $B/chat -H 'content-type: application/json' -d '{"session_id":"a1","message":"Capital of France?"}'
curl -s $B/chat -H 'content-type: application/json' -d '{"session_id":"a2","message":"Capital of France?"}'   # LLM_CACHE
# failover -> key_2 answers
curl -s $B/chat -H 'content-type: application/json' -H 'X-Simulate-Failure: key_1=429' -d '{"session_id":"a3","message":"Hello"}'
# all keys fail -> 503
curl -s -i $B/chat -H 'content-type: application/json' -H 'X-Simulate-Failure: *=429' -d '{"session_id":"a4","message":"Hello"}'
curl -s $B/sessions/a1/messages
```

In the UI, open **Session settings** and pick a failure preset to demo failover. Every reply shows source, model, latency and that request's input/output tokens (plus key and failed-key count).

## 5. Setup Used

- Editor: `<your editor>`
- AI tools: Claude (code generation and review) <edit to match what you used>

## 6. Bonus features

- UI failure-simulation dropdown (sends `X-Simulate-Failure`) so failover can be demoed without curl.
- Key cooldown after real provider failures to avoid hammering a dead key.
- `LLM_MOCK=true` runs the whole stack offline using LiteLLM mock responses; the backend tests use it.
- Configurable `LLM_MODEL`, timeout, history length and default system prompt.
